---
media: https://www.bilibili.com/video/BV1bJ4m1H75P/?p=6
---

- ![05-绪论-渐近记号-渐近下界Ω - 00:07|400](assets/05-绪论-渐近记号-渐近下界ΩPT7.649S.webp) [00:07](https://www.bilibili.com/video/BV1bJ4m1H75P/?p=6&t=7.648854#t=7.65) 

### 删阶


- ![05-绪论-渐近记号-渐近下界Ω - 01:31|400](assets/05-绪论-渐近记号-渐近下界ΩPT1M31.439S.webp) [01:31](https://www.bilibili.com/video/BV1bJ4m1H75P/?p=6&t=91.438997#t=01:31.44) 

- 代入 $n=1$ 满足公式

- ![05-绪论-渐近记号-渐近下界Ω - 02:16|400](assets/05-绪论-渐近记号-渐近下界ΩPT2M16.219S.webp) [02:16](https://www.bilibili.com/video/BV1bJ4m1H75P/?p=6&t=136.218623#t=02:16.22) 

### 答题卡书写



---


- ![07-绪论-O的计算性质 - 00:30|400](assets/07-绪论-O的计算性质PT30.375S.webp) [00:30](https://www.bilibili.com/video/BV1bJ4m1H75P/?p=6&t=30.374614#t=30.37) 

### 时间复杂度排行

- ![07-绪论-O的计算性质 - 01:10|400](assets/07-绪论-O的计算性质PT1M10.7S.webp) [01:10](https://www.bilibili.com/video/BV1bJ4m1H75P/?p=6&t=70.700255#t=01:10.70) 



- ![07-绪论-O的计算性质 - 03:03|400](assets/07-绪论-O的计算性质PT3M3.814S.webp) [03:03](https://www.bilibili.com/video/BV1bJ4m1H75P/?p=6&t=183.813622#t=03:03.81) 

### 计算公式

- 使用计算公式对于大 O 的计算

- ![07-绪论-O的计算性质 - 03:46|400](assets/07-绪论-O的计算性质PT3M46.308S.webp) [03:46](https://www.bilibili.com/video/BV1bJ4m1H75P/?p=6&t=226.308145#t=03:46.31) 


### 总结

- ![08-绪论-总结 - 02:14|400](assets/08-绪论-总结PT2M14.222S.webp) [02:14](https://www.bilibili.com/video/BV1bJ4m1H75P/?p=6&t=134.222349#t=02:14.22) 
### 证明渐进记号


---

## 分治法


- ![01-分治法-主方法 - 00:27|400](assets/01-分治法-主方法PT27.296S.webp) [00:27](https://www.bilibili.com/video/BV1bJ4m1H75P/?p=6&t=27.296324#t=27.30) 

### 主方法


- ![01-分治法-主方法 - 02:31|400](assets/01-分治法-主方法PT2M31.741S.webp) [02:31](https://www.bilibili.com/video/BV1bJ4m1H75P/?p=6&t=151.741214#t=02:31.74) 


- ![01-分治法-主方法 - 03:30|400](assets/01-分治法-主方法PT3M30.991S.webp) [03:30](https://www.bilibili.com/video/BV1bJ4m1H75P/?p=6&t=210.99108#t=03:30.99) 


- ![01-分治法-主方法 - 04:50|400](assets/01-分治法-主方法PT4M50.725S.webp) [04:50](https://www.bilibili.com/video/BV1bJ4m1H75P/?p=6&t=290.724683#t=04:50.72) 

- 要注意 $T(n/b)$ 其中 $b=2$

