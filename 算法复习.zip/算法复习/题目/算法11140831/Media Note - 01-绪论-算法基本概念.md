---
media: https://www.bilibili.com/video/BV1bJ4m1H75P/?p=2
---

- ![01-绪论-算法基本概念 - 00:19|450](assets/01-绪论-算法基本概念PT19.156S.webp) [00:19](https://www.bilibili.com/video/BV1bJ4m1H75P/?p=2&t=19.156068#t=19.16) 

---

### 满足

- ![01-绪论-算法基本概念 - 02:16|450](assets/01-绪论-算法基本概念PT2M16.6S.webp) [02:16](https://www.bilibili.com/video/BV1bJ4m1H75P/?p=2&t=136.599583#t=02:16.60) 



### 不满足


- ![01-绪论-算法基本概念 - 03:43|450](assets/01-绪论-算法基本概念PT3M43.412S.webp) [03:43](https://www.bilibili.com/video/BV1bJ4m1H75P/?p=2&t=223.41204#t=03:43.41) 

- ![01-绪论-算法基本概念 - 03:47|450](assets/01-绪论-算法基本概念PT3M47.887S.webp) [03:47](https://www.bilibili.com/video/BV1bJ4m1H75P/?p=2&t=227.887355#t=03:47.89) 

- ![01-绪论-算法基本概念 - 04:22|450](assets/01-绪论-算法基本概念PT4M22.685S.webp) [04:22](https://www.bilibili.com/video/BV1bJ4m1H75P/?p=2&t=262.685156#t=04:22.69) 

---


- ![02-绪论-时间复杂度 - 01:29|450](assets/02-绪论-时间复杂度PT1M29.83S.webp) [01:29](https://www.bilibili.com/video/BV1bJ4m1H75P/?p=2&t=89.83022#t=01:29.83) 

 
- ![04-绪论-渐近记号-渐近上界O - 01:48|450](assets/04-绪论-渐近记号-渐近上界OPT1M48.268S.webp) [01:48](https://www.bilibili.com/video/BV1bJ4m1H75P/?p=2&t=108.267841#t=01:48.27) 

### 升阶


- ![04-绪论-渐近记号-渐近上界O - 03:31|450](assets/04-绪论-渐近记号-渐近上界OPT3M31.323S.webp) [03:31](https://www.bilibili.com/video/BV1bJ4m1H75P/?p=2&t=211.322912#t=03:31.32) 

- ![04-绪论-渐近记号-渐近上界O - 04:06|450](assets/04-绪论-渐近记号-渐近上界OPT4M6.828S.webp) [04:06](https://www.bilibili.com/video/BV1bJ4m1H75P/?p=2&t=246.827836#t=04:06.83) 


- ![05-绪论-渐近记号-渐近下界Ω - 02:21|450](assets/05-绪论-渐近记号-渐近下界ΩPT2M21.719S.webp) [02:21](https://www.bilibili.com/video/BV1bJ4m1H75P/?p=2&t=141.719041#t=02:21.72) 

 
